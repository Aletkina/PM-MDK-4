﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication19
{
   internal class Program
    {
        static void Main()
        {
            string name;
           System.Console.WriteLine("Привет Яндекс");
            name = System.Console.ReadLine();
            System.Console.WriteLine("Приятно познакомиться");
            System.Console.ReadLine();
        }
    }
}
